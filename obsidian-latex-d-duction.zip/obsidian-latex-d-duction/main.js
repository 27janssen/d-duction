const { Plugin, renderMath } = require('obsidian');

// ==========================================
// 1. PARSER
// ==========================================
function tokenize(source) {
	const tokens = [];
	let i = 0;
	const len = source.length;

	while (i < len) {
		if (source[i] === '\\') {
			let j = i + 1;
			while (j < len && /[a-zA-Z]/.test(source[j])) j++;
			const cmd = source.substring(i + 1, j);
			i = j;
			
			while (i < len && /\s/.test(source[i])) i++;

			let arg = null;
			if (i < len && source[i] === '{') {
				let depth = 1;
				let k = i + 1;
				while (k < len && depth > 0) {
					if (source[k] === '{') depth++;
					else if (source[k] === '}') depth--;
					k++;
				}
				arg = source.substring(i + 1, k - 1);
				i = k;
			}
			tokens.push({ cmd, arg });
		} else {
			i++;
		}
	}
	return tokens;
}

function buildTree(tokens) {
	const stack = [];
	let pendingLeft = '';
	let pendingRight = '';
	let pendingLine = 'single';

	const resetPending = () => {
		pendingLeft = '';
		pendingRight = '';
		pendingLine = 'single';
	};

	for (const token of tokens) {
		const { cmd, arg } = token;

		if (cmd === 'begin' || cmd === 'end') continue;

		if (cmd === 'LeftLabel') pendingLeft = arg || '';
		else if (cmd === 'RightLabel') pendingRight = arg || '';
		else if (cmd === 'doubleLine') pendingLine = 'double';
		else if (cmd === 'dashedLine') pendingLine = 'dashed';
		else if (cmd === 'dottedLine') pendingLine = 'dotted';
		else if (cmd === 'noLine') pendingLine = 'none';
		else if (cmd === 'AxiomC' || cmd === 'Axiom') {
			stack.push({ text: arg, children: [], left: pendingLeft, right: pendingRight, line: pendingLine });
			resetPending();
		} 
		else if (['UnaryInfC', 'BinaryInfC', 'TrinaryInfC', 'QuaternaryInfC', 'QuinaryInfC'].includes(cmd)) {
			const arity = { 'UnaryInfC': 1, 'BinaryInfC': 2, 'TrinaryInfC': 3, 'QuaternaryInfC': 4, 'QuinaryInfC': 5 }[cmd];
			if (stack.length < arity) throw new Error(`${cmd} requires ${arity} hypotheses, but only ${stack.length} found.`);
			
			const children = [];
			for (let k = 0; k < arity; k++) children.unshift(stack.pop());
			
			stack.push({ text: arg, children, left: pendingLeft, right: pendingRight, line: pendingLine });
			resetPending();
		} 
		else if (cmd === 'DisplayProof') {
			// Finalize
		}
	}

	if (stack.length !== 1) {
		throw new Error(`Proof tree is not well-formed. Final stack size: ${stack.length}. Check your inferences.`);
	}
	return stack[0];
}

// ==========================================
// 2. RENDERER
// ==========================================
function renderNode(node) {
	const nodeEl = document.createElement('div');
	nodeEl.className = 'd-duction-node';

	if (node.children.length > 0) {
		const childrenEl = document.createElement('div');
		childrenEl.className = 'd-duction-children';
		for (const child of node.children) {
			childrenEl.appendChild(renderNode(child));
		}
		nodeEl.appendChild(childrenEl);
	}

	if (node.children.length > 0 || node.line !== 'none') {
		const inferenceEl = document.createElement('div');
		inferenceEl.className = 'd-duction-inference';

		if (node.left) {
			const leftEl = document.createElement('span');
			leftEl.className = 'd-duction-label d-duction-label-left';
			leftEl.textContent = node.left;
			inferenceEl.appendChild(leftEl);
		}

		const lineEl = document.createElement('div');
		lineEl.className = `d-duction-line ${node.line}`;
		inferenceEl.appendChild(lineEl);

		if (node.right) {
			const rightEl = document.createElement('span');
			rightEl.className = 'd-duction-label d-duction-label-right';
			rightEl.textContent = node.right;
			inferenceEl.appendChild(rightEl);
		}
		nodeEl.appendChild(inferenceEl);
	}

	const textEl = document.createElement('div');
	textEl.className = 'd-duction-text';
	try {
		const mathEl = renderMath(node.text, false);
		textEl.appendChild(mathEl);
	} catch (e) {
		textEl.textContent = node.text;
	}
	nodeEl.appendChild(textEl);

	return nodeEl;
}

function renderProoftree(source) {
	const container = document.createElement('div');
	container.className = 'd-duction-container';
	try {
		const tokens = tokenize(source);
		const tree = buildTree(tokens);
		container.appendChild(renderNode(tree));
	} catch (e) {
		const errEl = document.createElement('div');
		errEl.className = 'd-duction-error';
		errEl.textContent = `D-duction Error:\n${e.message}`;
		container.appendChild(errEl);
	}
	return container;
}

// ==========================================
// 3. MAIN PLUGIN CLASS
// ==========================================
class DductionPlugin extends Plugin {
	async onload() {
		console.log('Loading D-duction plugin');

		// Register the custom code block processor
		this.registerMarkdownCodeBlockProcessor('d-duction', (source, el, ctx) => {
			el.appendChild(renderProoftree(source));
		});
	}

	onunload() {
		console.log('Unloading D-duction plugin');
	}
}

module.exports = DductionPlugin;